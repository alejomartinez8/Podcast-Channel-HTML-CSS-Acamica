# Podcast-Channel-HTML-CSS-Acamica

Bloque 1 - Proyecto 1 - Curso FullStack Acámica

git: https://github.com/alejomartinez8/Podcast-Channel-HTML-CSS-Acamica
demo: https://elegant-panini-66c517.netlify.app/